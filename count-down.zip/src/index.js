import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

function countDown(){
  //var theTime=new Date();
   var timeObject = new Date();
// let milliseconds= 10 * 1000; // 10 seconds = 10000 milliseconds
 //timeObject = new Date(timeObject.getTime() + 4000);
  var countDownDate = timeObject.setMinutes(timeObject.getMinutes() + 20)+3000;

  var x = setInterval(function(){
    var now = new Date().getTime();
    var distance = countDownDate - now;

    var days = Math.floor(distance/(1000 * 60 * 60 * 24));
    var hours = Math.floor((distance%(1000* 60 * 60 * 24))/(1000 * 60 * 60));
    var minutes = Math.floor((distance% (1000 * 60 * 60))/(1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    //document.getElementById("root").innerHTML = days + "days "+hours + "hours "+minutes+"minutes "+seconds+ "seconds";
    document.getElementById("root").innerHTML = minutes+"minutes "+seconds+ "seconds";

    if(distance<0){
      clearInterval(x);
      document.getElementById("root").innerHTML = "Expired";
    }
  },2000);
}
countDown();
ReactDOM.render(<countDown/>,document.getElementById("root"));



